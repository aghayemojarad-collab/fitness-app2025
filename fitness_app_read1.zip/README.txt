
راهنما:
این ZIP شامل سورس اپ Kivy + buildozer.spec + workflow GitHub Actions برای ساخت APK است.

مراحل:
1- این ZIP را دانلود و روی GitHub خودت آپلود کن.
2- فایل‌ها را commit و push کن.
3- به تب Actions برو، workflow اجرا خواهد شد و APK ساخته می‌شود.
4- APK ساخته شده را می‌توانی از بخش Artifacts دانلود کنی.
